import './App.scss'
import React from 'react'

/**
 * @function App
 */
const App = (props) => <div>React 앱</div>

export default App
