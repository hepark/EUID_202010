<style>
  .note { margin-bottom: 1.5rem; padding: 12px; border-radius: 5px; background: #f2f2f2; color: #303952; }
  .note-title { display: block; margin-bottom: 1em; font-weight: bold; color: #111 }
  .note a { text-decoration: none; color: inherit; }
  .note p { margin-bottom: 0.6em; line-height: 1.7 }
  .note p:last-child { margin-bottom: 0.2em; }
  .icon { vertical-align: -4px; margin-right: 5px; width: 20px; height: 20px; }
  .icon path { fill: red; }

  /* GitHub Code Style */
  .hljs-attr { color: #221877; }
  .hljs-string { color: #C2185B; }
</style>

<!-- 

<div class="note">
  <strong class="note-title">📝 NOTE.</strong>
  <p></p>
</div> 

[<svg class="icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/></svg> Firebase 인증 방법 설정 및 데이터베이스 만들기](https://youtu.be/fCP_ATkzDdg) 

-->

# 서비스로서의 백엔드 

웹 또는 앱 개발자가 서버 기술을 몰라도 서버 환경에 연결되는 웹 서비스, 모바일 앱을 만들 수 있도록 도와주는 BaaS(Backend as a Service)입니다. 
서버와 통신하는 웹 또는 모바일 앱 개발에 필요한 특정 기능을 지원하는 환경으로 클라우드 서비스형 플랫폼(PaaS)에 속합니다. 

![](_/baas.jpg)

개발자가 웹 서비스 또는 앱을 개발할 때마다 데이터베이스, 데이터 관리(예: 사용자 정보 등), 파일 스토리지, 네트워크 접속 제어(보안), 푸시 알림, SNS 통합, 위치 기반 서비스 등 백엔드 기능을 구현하기 위해 코드를 직접 개발해야 하지만, 서비스형 백엔드(BaaS)를 이용하면 직접 코드를 개발하지 않고 웹 또는 앱을 클라우드와 연동시켜 BaaS에서 제공하는 애플리케이션 인터페이스(API)를 호출하여 사용할 수 있습니다. 

따라서 서비스 개발 시간을 크게 단축하고 코드의 복잡성을 줄일 수 있을 뿐만 아니라, Front-End 개발을 책임지는 UI 개발자는 별도의 Back-End 개발자의 도움 없이도 
UI 개발에 집중하여 웹 서비스 또는 모바일 앱을 구축할 수 있습니다.

![](_/front-end--baas.jpg)

<div class="note">
  <strong class="note-title">📝 NOTE.</strong>
  <p>BaaS를 세밀하게 제어하기 위해서는 서버 기술에 대한 지식과 경험이 필요하므로 Back-End 개발자의 도움이 필요합니다!</p>
</div>

## BaaS? 유료 서비스 아닌가요?

서비스로서의 백엔드는 대부분 무료 요금제로 시작하며, 특정 임계 값 이후에 서비스 요금이 청구됩니다. 유료 요금제가 실행되는 기준은
일반적으로 API 요청 또는 API 호출, 데이터베이스 크기, 파일 저장소 또는 데이터 전송입니다.

## BaaS 리스트

다음은 Back-End를 서비스로 제공하는 업체 목록입니다.

- [Parse](https://parseplatform.org/) - 영문 문서만 제공
- [AWS Amplify](https://aws.amazon.com/ko/amplify/) - 한글 문서 일부 제공
- Google [Firebase](https://firebase.google.com/) - 한글 문서 일부 제공
- ...

## BaaS 처럼 Front-End 개발도 서비스로 만들 수 없나요?

Back-End와 달리, Front-End가 담당하는 UI는 정규화(설계(design)에서 중복을 최소화하기 위해 데이터를 구조화 하는 프로세스)하기가 어렵습니다.
클라이언트 또는 최종 사용자의 요구사항에 따라 수시각각 상황이 변할 수 있어 전체 프로세스를 패턴화 하기 힘듭니다. 예를 들어 서비스의 UI가
제공하지 않는 특별한 기능 또는 독창적인 애니메이션 등 클라이언트의 요구를 정규화 된 서비스가 처리할 수 없기 때문입니다.

하지만 일반적으로 자주 사용되는 UI 컴포넌트 또는 템플릿을 서비스로 제공할 수는 있습니다. 대표적인 예가 Wordpress의 테마(Theme)나,
Bootstrap 같은 UI 프레임워크 입니다. 이러한 것을 사용해 Front-End 개발 전문가 없이도 UI를 구현할 수 있습니다.

다만, 공장에서 찍어낸 것처럼 획일적인 UI가 구성됩니다. 당연하겠죠. 템플릿을 그대로 사용한 것이니까요.
즉, BaaS 또는 UI 프레임워크나 CMS 테마를 사용하면 어느 정도 필요한 부분을 구현할 수 있지만... 그것이 한계입니다. 결국 정규화하지 못한 영역은
전문가의 손길이 필요합니다. 만약... 모든 것을 정규화 할 수 있다면? 더 이상 인간이 설 자리는 없을 것입니다. (인류 멸망? ^^;)

<div class="note">
  <strong class="note-title">📝 NOTE.</strong>
  <p>대부분의 Back-End 개발 수업에서 Front-End를 직접 구현해보지 않고, UI 프레임워크를 가져다 획일적인 UI를 구성합니다. 그렇다 보니 Front-End 개발이 우수워 보이는 것일테죠. 
  마찬가지로 Front-End 개발 수업에서 Back-End를 직접 구현해보지 않고, BaaS를 사용하면 Back-End 개발에 대해 잘못된 편견을 가질 수 있습니다. 세상에 쉬운 일이 어딨겠습니까? 
  각 분야의 전문성을 서로 존중 합시다!</p>
</div>