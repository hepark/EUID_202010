# Mini Project {E0}

React 앱으로 제작해보는 미니 프로젝트

## UI 실습

자주 사용되는 배열 메서드를 사용해 UI를 업데이트 하는 앱을 React로 구현하는 학습을 진행합니다.

> 📼 `assets/array-methods-dom.mp4` 파일을 열어 인터랙션을 살펴보고 실습을 진행해보세요.

![](./assets/array-methods-dom.gif)

## 학습 내용

실습을 통해 다음 학습을 진행합니다.

### JavaScript(ES6) 파트

- 자산가 랜덤 생성 유틸리티 함수
  - 성 + 이름 랜덤 생성
  - 자산 금액 랜덤 생성
- 숫자를 대한민국 통화(원)로 변경하는 유틸리티 함수
  - 정규 표현식(RegExp) 활용

### React 앱 파트

- 프로젝트 생성
- 정적 리소스 관리
- 유틸리티 함수 구현/활용
- React 앱 초기 렌더링
- React 이벤트 핸들링
- React 컴포넌트 분리/관리
- React 컴포넌트 간 통신
- React 컨텍스트 생성/활용
- React 테스팅 라이브러리

<br>

## 프로젝트 가이드

유티릴티 함수 작성에 필요한 정보이니 내용을 확인한 후, 각 함수 로직을 구현해보세요.

### 자산가 구조 

자산(wealth, 부)을 가진 사람은 JavaScript 객체입니다.

속성 | 값 | 데이터 유형
--- | --- | ---
`name` | 자산가 이름 | String
`wealth` | 자산 금액 | Number

### 자산가 이름

자산가의 이름은 '성 + 이름' 조합으로 랜덤 생성되도록 구현 합니다.

유형 | 값
--- | ---
성 이름 | '김이박최정강조윤장임한오서신권황안송류전홍고문양손배조백허유지'
이름 | '이겸,아름,다운,유진,훈,수진,예진,인영,지훈,동현,기호,승현,나연,다영,재인,구영,미나,서연,지우,지아,민준,건우'

### 자산 금액

자산 금액은 최대 10억(`100000000`)원으로 설정합니다.

### 연산과 표시의 이원화

자산액을 연산하기 위해서는 데이터 유형이 숫자(Number)여야 합니다.<br>
하지만 UI에 표시될 때는 문자(String) 값으로 출력되어야 합니다.

과정 | 설명 | 예시
--- | --- | ---
렌더링 전 | 수학 연산 | 872304900
렌더링 후 | 문자 표시 | '872,304,900원'

### 유틸리티 함수 구현에 사용되는 배열 메서드

아래 목록은 자주 사용되는 배열 메서드를 정리한 것입니다. 유틸리티 함수를 구현하는데 참고하세요.

메서드 | 설명 | 반환 값
--- | --- | ---
[Array.prototype.forEach()](https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/forEach) | 주로 반환 값을 참조할 필요가 없는 배열 반복 처리에 사용됩니다. | `undefined`
[Array.prototype.map()](https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/map) | 아이템을 가공하여 새로운 배열을 만들어야 할 때 사용합니다. | 새로운 배열 객체
[Array.prototype.filter()](https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/filter) | 아이템 중 일부를 걸러낼 때 사용합니다. | 새로운 배열 객체
[Array.prototype.slice()](https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/slice) | 아이템 중 일부를 잘라내거나, 복제할 때 사용합니다. | 새로운 배열 객체
[Array.prototype.splice()](https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/splice) | 새 아이템을 특정 위치에 추가하거나, 아이템 제거에 사용됩니다. | 업데이트 된 배열 객체
[Array.prototype.sort()](https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/sort) | 아이템을 정렬할 때 사용합니다. | 업데이트 된 배열 객체
[Array.prototype.reduce()](https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/reduce) | 아이템을 연산하여 하나의 값을 도출할 때 사용합니다. ( L → R ) | 계산된 결과 값
[Array.prototype.isArray()](https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/isArray) | 인자 값의 데이터 유형이 배열인지 확인합니다. | Boolean
[Array.prototype.join()](https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/join) | 아이템을 묶어 문자 값으로 만들 때 사용합니다. | Boolean
[Array.prototype.reduceRight()](https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/reduceRight) | 아이템을 연산하여 하나의 값을 도출할 때 사용합니다. ( L ← R ) | 계산된 결과 값
[Array.prototype.some()](https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/some) | 아이템 마다 검사하여 일부라도 검사 값이 참이면 `true`를 반환합니다. | Boolean
[Array.prototype.every()](https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/every) | 아이템 마다 검사하여 모두 검사 값이 참이면 `true`를 반환합니다. | Boolean
[Array.from()](https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/from) | 유사 배열(`arguments`, nodeList 등)을 배열로 변경합니다. | 새로운 배열 | [폴리필](https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/from#%ED%8F%B4%EB%A6%AC%ED%95%84)
[Array.of()](https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/of) | 정수형 인자 값을 아이템으로 하는 배열 생성 시 사용합니다. | 새로운 배열 | [폴리필](https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/of#Polyfill)
[Array.prototype.fill()](https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/fill) | 아이템을 다른 값으로 일괄 채울 때 사용합니다. | 업데이트 된 배열 | [폴리필](https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Array/fill#Polyfill)

### 자산가 템플릿

React에서 자산가 리스트를 순환할 때 사용되는 템플릿은 다음과 같습니다.

```html
<h2 className="headline">
  <strong>이름</strong>
  <strong>자산금액(대한민국 통화, 원)</strong>
</h2>
```

### 자산 금액 총합 계산 템플릿

React에서 자산 금액 총합을 계산해 UI에 표시할 때 사용되는 템플릿은 다음과 같습니다.

```html
<h3 className="subHeadline">
  <strong>자산 총액</strong>
  <strong>1,000,000,000원</strong>
</h3>
```